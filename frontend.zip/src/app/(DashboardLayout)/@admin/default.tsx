

const AdminDefault = () => {
    return (
        null
    );
};

export default AdminDefault;