import { redirect } from "next/navigation";

export default function AddressRedirectPage() {
  redirect("/dashboard/address");
}
